CREATE PROCEDURE sais(eid in NUMBER)
  AS
  psal EMPLOY.sal%TYPE;
  BEGIN
    SELECT SAL INTO psal FROM EMPLOY WHERE EMPNO=eid;
    dbms_output.put_line(psal);
  END;
/
