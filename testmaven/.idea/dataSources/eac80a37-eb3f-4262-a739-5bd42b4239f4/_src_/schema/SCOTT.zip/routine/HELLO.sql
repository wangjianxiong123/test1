CREATE PROCEDURE hello
  AS 
  BEGIN
    dbms_output.put_line('helloWorld');
  END;
/
